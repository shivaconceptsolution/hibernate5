package com.scs.hiberexample;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;





/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Employee obj = new Employee();
        obj.setEmpid(1002);
        obj.setEmpname("emp2");
        session.save(obj);
        session.getTransaction().commit();
        TypedQuery<Employee> q = session.createQuery("From Employee", Employee.class);
        List<Employee> resultList = q.getResultList();
        System.out.println("total sudents:" + resultList.size());
        
        for (Employee s : resultList) {
          System.out.println("emp : " + s.getEmpid()+ " "+s.getEmpname());
        }
        
    }
}
