package com.scs.hiberexample;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_empnew")
public class Empnew {
	@Id	
	private int empid;
	@Column
	private String empname;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="deptid",referencedColumnName="deptid")
	private Deptnew deptnew;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Deptnew getDeptnew() {
		return deptnew;
	}
	public void setDeptnew(Deptnew deptnew) {
		this.deptnew = deptnew;
	}
	
	
}
