package com.scs.hiberexample;

import org.hibernate.Session;

public class Manytoone {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Deptnew d = new Deptnew();
		d.setDeptid(20);
		d.setDeptname("CS");
		Empnew em = new Empnew();
		em.setEmpid(1001);
		em.setEmpname("SSS");
		em.setDeptnew(d);
		Empnew em1 = new Empnew();
		em1.setEmpid(1002);
		em1.setEmpname("DDD");
		em1.setDeptnew(d);
		session.save(em);
		session.save(em1);
		session.getTransaction().commit();
        session.close();
	}

}
