package com.scs.hiberexample;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

public class OneToManyExecution {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Dept d = new Dept();
        d.setDeptid(20);
        d.setDeptname("SALES");
        Emp e1 = new Emp();
        e1.setEmpid(1003);
        e1.setEmpname("EMP3");
        Emp e2 = new Emp();
        e2.setEmpid(1004);
        e2.setEmpname("EMP4");
        Set st = new HashSet<Emp>();
        st.add(e1);
        st.add(e2);
        d.setEmpref(st);
        session.save(d);
        session.getTransaction().commit();
        session.close();
        

	}

}
