package com.scs.Hibernate5;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Student student = new Student();
        student.setFirstName("John");
        student.setLastName("Bloch");
        student.setContactNo("+1-408-575-1317");
        session.save(student);
        session.getTransaction().commit();
      //  Query<Student> q = session.createQuery("From Student", Student.class);
        TypedQuery<Student> q = session.createQuery("From Student", Student.class);
        List<Student> resultList = q.getResultList();
        System.out.println("total sudents:" + resultList.size());
        
        for (Student s : resultList) {
          System.out.println("student : " + s);
        }
      }
    }

